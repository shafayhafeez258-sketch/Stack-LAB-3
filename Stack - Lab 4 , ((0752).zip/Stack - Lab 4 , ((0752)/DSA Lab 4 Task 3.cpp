#include <iostream>
using namespace std;

class myCarStack {
private:
    string* cars;
    int capacity;
    int carTop;

public:
    myCarStack(int size = 8) {
        capacity = size;
        cars = new string[capacity];
        carTop = -1;
    }

    void push(string carNumber) {
        if (isFull()) {
            cout << "Parking lot is full!\n";
            return;
        }

        cars[++carTop] = carNumber;
        cout << "Car " << carNumber << " parked successfully.\n";
    }

    string pop() {
        if (isEmpty()) {
            return "";
        }

        return cars[carTop--];
    }

    string top() const {
        if (isEmpty()) {
            return "";
        }

        return cars[carTop];
    }

    bool isEmpty() const {
        return carTop == -1;
    }

    bool isFull() const {
        return carTop == capacity - 1;
    }

    int totalCars() const {
        return carTop + 1;
    }

    bool search(string carNumber) const {
        for (int i = 0; i <= carTop; i++) {
            if (cars[i] == carNumber) {
                return true;
            }
        }

        return false;
    }

    void display() const {
        if (isEmpty()) {
            cout << "No cars are parked.\n";
            return;
        }

        cout << "\nCars in parking lot (Top to Bottom):\n";

        for (int i = carTop; i >= 0; i--) {
            cout << cars[i] << endl;
        }
    }

    void removeCar(string carNumber) {
        if (!search(carNumber)) {
            cout << "Car not found in parking lot.\n";
            return;
        }

        myCarStack temp(capacity);

        while (top() != carNumber) {
            temp.push(pop());
        }

        pop();
        cout << "Car " << carNumber << " removed successfully.\n";

        while (!temp.isEmpty()) {
            push(temp.pop());
        }
    }

    ~myCarStack() {
        delete[] cars;
    }
};

int main() {
    myCarStack parking(8);

    int choice;
    string carNumber;

    do {
        cout << "\n===== PARKING LOT MANAGEMENT =====\n";
        cout << "1. Park a new car\n";
        cout << "2. Remove a car\n";
        cout << "3. Display parked cars\n";
        cout << "4. Show total cars parked\n";
        cout << "5. Search for a car\n";
        cout << "6. Show top car\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter car number: ";
            cin >> carNumber;

            if (parking.search(carNumber)) {
                cout << "This car is already parked!\n";
            }
            else {
                parking.push(carNumber);
            }
            break;

        case 2:
            cout << "Enter car number to remove: ";
            cin >> carNumber;
            parking.removeCar(carNumber);
            break;

        case 3:
            parking.display();
            break;

        case 4:
            cout << "Total cars parked: "
                << parking.totalCars() << "/8\n";
            break;

        case 5:
            cout << "Enter car number to search: ";
            cin >> carNumber;

            if (parking.search(carNumber)) {
                cout << "Car is present in the parking lot.\n";
            }
            else {
                cout << "Car is not present.\n";
            }
            break;

        case 6:
            if (parking.isEmpty()) {
                cout << "Parking lot is empty.\n";
            }
            else {
                cout << "Top car: " << parking.top() << endl;
            }
            break;

        case 7:
            cout << "Parking system closed.\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 7);

    return 0;
}
