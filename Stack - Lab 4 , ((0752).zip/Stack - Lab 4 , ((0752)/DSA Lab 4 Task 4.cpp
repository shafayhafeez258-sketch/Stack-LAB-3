#include <iostream>
using namespace std;

class TextEditor {
private:
    char text[1000];
    int textTop;

    char undoStack[1000];
    char redoStack[1000];

    int undoTop;
    int redoTop;

public:
    TextEditor() {
        textTop = -1;
        undoTop = -1;
        redoTop = -1;
    }

    void typeCharacter(char ch) {
        if (textTop == 998) {
            cout << "Text is full!\n";
            return;
        }

        text[++textTop] = ch;
        undoStack[++undoTop] = 'T';
        redoTop = -1;

        cout << "Character typed successfully.\n";
    }

    void deleteCharacter() {
        if (textTop == -1) {
            cout << "No text to delete!\n";
            return;
        }

        char deleted = text[textTop--];

        undoStack[++undoTop] = deleted;
        redoTop = -1;

        cout << "Character deleted successfully.\n";
    }

    void undo() {
        if (undoTop == -1) {
            cout << "Nothing to undo!\n";
            return;
        }

        char action = undoStack[undoTop--];

        if (action == 'T') {
            redoStack[++redoTop] = text[textTop--];
        }
        else {
            text[++textTop] = action;
            redoStack[++redoTop] = 'D';
        }

        cout << "Undo successful.\n";
    }

    void redo() {
        if (redoTop == -1) {
            cout << "Nothing to redo!\n";
            return;
        }

        char action = redoStack[redoTop--];

        if (action == 'D') {
            undoStack[++undoTop] = text[textTop];
            textTop--;
            undoStack[++undoTop] = 'D';
        }
        else {
            text[++textTop] = action;
            undoStack[++undoTop] = 'T';
        }

        cout << "Redo successful.\n";
    }

    void displayText() {
        cout << "\nCurrent Text: ";

        for (int i = 0; i <= textTop; i++) {
            cout << text[i];
        }

        cout << endl;
    }
};

int main() {
    TextEditor editor;
    int choice;
    char ch;

    do {
        cout << "\n===== TEXT EDITOR =====\n";
        cout << "1. Type a character\n";
        cout << "2. Delete last character\n";
        cout << "3. Undo\n";
        cout << "4. Redo\n";
        cout << "5. Display text\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter character: ";
            cin >> ch;
            editor.typeCharacter(ch);
            break;

        case 2:
            editor.deleteCharacter();
            break;

        case 3:
            editor.undo();
            break;

        case 4:
            editor.redo();
            break;

        case 5:
            editor.displayText();
            break;

        case 6:
            cout << "Text editor closed.\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 6);

    return 0;
}
